package com.example.dopamine.bootstrap;

import com.example.dopamine.domain.User;
import com.example.dopamine.domain.Note;
import com.example.dopamine.domain.Role;
import com.example.dopamine.services.RoleService;
import com.example.dopamine.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.HashSet;

@Component
public class DataLoader implements CommandLineRunner{
    @Autowired
    private final UserService userService;
    private final RoleService roleService;

    public DataLoader(UserService userService, RoleService roleService) {
        this.userService = userService;
        this.roleService = roleService;
    }


    @Override
    public void run(String... args) throws Exception{
        PasswordEncoder bcrypt = new BCryptPasswordEncoder();
        User user0=new User("admin",bcrypt.encode("admin"));
        User user1=new User("user1",bcrypt.encode("user1"));
        User user2=new User("user2",bcrypt.encode("user2"));

        Role admin = new Role("ADMIN");
        Role user = new Role("USER");


        user0.setRoles(new HashSet<Role>(Arrays.asList(admin)));
        user2.setRoles(new HashSet<Role>(Arrays.asList(user)));
        user1.setRoles(new HashSet<Role>(Arrays.asList(user)));

        Note n1 = new Note("Buy groceries");

        user1.addNote(n1);

        roleService.save(admin);
        roleService.save(user);
        userService.save(user0);
        userService.save(user1);
        userService.save(user2);


    }

}
