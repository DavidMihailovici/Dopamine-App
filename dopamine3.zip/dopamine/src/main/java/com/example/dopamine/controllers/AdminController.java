package com.example.dopamine.controllers;

import com.example.dopamine.domain.Role;
import com.example.dopamine.domain.User;
import com.example.dopamine.services.RoleService;
import com.example.dopamine.services.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;


@Controller
@Slf4j
@RequestMapping("/admin")

public class AdminController {
    @Autowired
    private final UserService userService;
    @Autowired
    private final RoleService roleService;

    public AdminController(UserService userService, RoleService roleService){
        this.userService = userService;
        this.roleService = roleService;
    }

    @GetMapping
    public String seeUsers(Model model){
        model.addAttribute("users", userService.findAll());
        model.addAttribute("usersWithNoNotes", userService.findUsersWithNoNotes());
        return "/admin";
    }

    @PostMapping()
    public String deleteUser(@RequestParam(value = "username") String username, Model model){
        User user = userService.findUserByUsername(username);
        userService.remove(user);
        model.addAttribute("users", userService.findAll());
        model.addAttribute("usersWithNoNotes", userService.findUsersWithNoNotes());
        return "/admin";
    }
}
