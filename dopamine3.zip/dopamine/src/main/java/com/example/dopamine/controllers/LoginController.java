package com.example.dopamine.controllers;

import com.example.dopamine.domain.Note;
import com.example.dopamine.domain.User;
import com.example.dopamine.services.SecurityService;
import com.example.dopamine.services.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;


@Controller
@Slf4j
@RequestMapping("/")

public class LoginController {
    private UserService userService;
    @Autowired
    private SecurityService securityService;
    private UserValidator userValidator;

    public LoginController(UserService userService){this.userService = userService;}

    @GetMapping
    public String login(){
        return "login";
    }

    @GetMapping("/login")
    public String getLogin(Model model, String error, String logout) {

        if (error != null) {
            model.addAttribute("error", "Your username and password is invalid.");
            return "login";
        }

        if (logout != null) {
            model.addAttribute("message", "You have been logged out successfully.");
            return "login";
        }

        return "login";
    }

    @PostMapping("/login_success_handler")
    public String loginSuccessHandler(){
        return "redirect:/notes";
    }

}
