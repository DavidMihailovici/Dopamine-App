package com.example.dopamine.controllers;

import com.example.dopamine.domain.Note;
import com.example.dopamine.domain.User;
import com.example.dopamine.services.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;


@Controller
@Slf4j
@RequestMapping("/notes")
public class NoteController {
    @Autowired
    private final UserService userService;

    public NoteController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping
    public String seeNotes(Model model){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUser = authentication.getName();
        model.addAttribute("userNotes", userService.findNotesUser(currentUser));
        return "notes";
    }

    @PostMapping
    public String addNote(Model model, String text,  String error){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUserString = authentication.getName();
        User currentUser = userService.findUserByUsername(currentUserString);
        if(text.isEmpty()){
            model.addAttribute("error", "Note can't be empty.");
            userService.save(currentUser);
            model.addAttribute("userNotes", userService.findNotesUser(currentUserString));
            return "notes";
        }
        Note noteToAdd = new Note(text);
        currentUser.addNote(noteToAdd);
        userService.save(currentUser);
        model.addAttribute("userNotes", userService.findNotesUser(currentUserString));
        return "notes";
    }

    @PostMapping("/delete")
    public String deleteNote(@RequestParam String text, Model model){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUserString = authentication.getName();
        User currentUser = userService.findUserByUsername(currentUserString);
        /*currentUser.removeNote(note);*/
        userService.save(currentUser);
        model.addAttribute("userNotes", userService.findNotesUser(currentUserString));
        return "notes";
    }
}
