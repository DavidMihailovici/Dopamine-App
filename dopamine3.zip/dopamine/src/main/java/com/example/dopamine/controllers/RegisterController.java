package com.example.dopamine.controllers;

import com.example.dopamine.domain.Note;
import com.example.dopamine.domain.User;
import com.example.dopamine.services.SecurityService;
import com.example.dopamine.services.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;


@Controller
@Slf4j
@RequestMapping("/register")

public class RegisterController {
    @Autowired
    private UserService userService;

    @GetMapping
    public String register(Model model){
        UserDTO userDto = new UserDTO();
        model.addAttribute("user", userDto);
        return "register";
    }

    @PostMapping
    public String registerUser(UserDTO userDTO){
        userService.registerNewUser(userDTO);
        return "redirect:/login";
    }

}
