package com.example.dopamine.controllers;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDTO {
    private String username;
    private String password;
    private String repeatPass;
    private String email;
}
