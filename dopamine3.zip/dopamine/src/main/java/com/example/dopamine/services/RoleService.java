package com.example.dopamine.services;

import com.example.dopamine.domain.Role;
import com.example.dopamine.domain.User;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public interface RoleService {
    Role save(Role role);
    List<Role> findAllRoles();
    Role findRole(String roleName);
    Role remove(Role role);

}
