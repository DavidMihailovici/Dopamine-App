package com.example.dopamine.services;

import com.example.dopamine.domain.User;
import com.example.dopamine.domain.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.util.HashSet;
import java.util.List;

@Service
public class RoleServiceEm implements RoleService {
    @PersistenceContext
    private EntityManager em;

    @Autowired
    private UserService userService;
    @Autowired
    private RoleService roleService;

    @Override
    @Transactional
    public Role save(Role role){
        em.persist(role);
        return role;
    }

    @Override
    @Transactional
    public Role remove(Role role){
        em.remove(em.merge(role));
        System.out.println("Removed " + role);
        return role;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Role> findAllRoles() {
        TypedQuery<Role> query = em.createQuery("SELECT r FROM Role r", Role.class);
        return query.getResultList();
    }

    @Override
    @Transactional(readOnly = true)
    public Role findRole(String roleName){
        TypedQuery<Role> query = em.createQuery("SELECT r FROM Role r WHERE r.name = :roleName", Role.class);
        query.setParameter("roleName", roleName);
        return query.getSingleResult();
    }

}
