package com.example.dopamine.services;

import com.example.dopamine.controllers.UserDTO;
import com.example.dopamine.domain.Note;
import com.example.dopamine.domain.User;
import java.util.List;

public interface UserService {
    User save(User user);
    List<User> findAll();
    User findUserByUsername(String username);
    List<User> findUsersWithNoNotes();
    List<Note> findNotesUser(String username);
    User registerNewUser(UserDTO userDTO);
    User remove(User user);
    Note findNoteUser(String username, String text);
}
