package com.example.dopamine.services;

import com.example.dopamine.controllers.UserDTO;
import com.example.dopamine.domain.Note;
import com.example.dopamine.domain.User;
import com.example.dopamine.domain.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.util.HashSet;
import java.util.List;

@Service
public class UserServiceEm implements UserService{
    @PersistenceContext
    private EntityManager em;

    @Autowired
    private UserService userService;
    @Autowired
    private RoleService roleService;

    @Override
    @Transactional
    public User save(User user) {
        em.persist(em.merge(user));
        return user;
    }


    @Override
    @Transactional
    public User remove(User user){
        em.remove(em.merge(user));
        System.out.println("remove was used");
        System.out.println(user);
        return user;
    }

    @Override
    public List<User> findAll() {
        TypedQuery<User> query = em.createQuery("SELECT u FROM User u", User.class);
        return query.getResultList();
    }

    @Override
    public User findUserByUsername(String username) throws UsernameNotFoundException {
        TypedQuery<User> query = em.createQuery("SELECT u FROM User u WHERE u.username = :username", User.class);
        query.setParameter("username",username);
        return query.getSingleResult();
    }

    @Transactional(readOnly = true)
    @Override
    public List<User> findUsersWithNoNotes() {
        TypedQuery<User> query = em.createQuery("SELECT u FROM User u WHERE u.notes IS EMPTY", User.class);
        return query.getResultList();
    }

    @Transactional(readOnly = true)
    @Override
    public List<Note> findNotesUser(String username) {
        TypedQuery<Note> query = em.createQuery("SELECT n FROM Note n INNER JOIN n.user u WHERE u.username = :username", Note.class);
        query.setParameter("username", username);
        return query.getResultList();
    }

    @Transactional(readOnly = true)
    @Override
    public Note findNoteUser(String username, String text) {
        TypedQuery<Note> query = em.createQuery("SELECT n FROM Note n INNER JOIN n.user u WHERE u.username = :username AND n.text = :text", Note.class);
        query.setParameter("username", username);
        query.setParameter("text", text);
        return query.getSingleResult();
    }

    @Transactional
    @Override
    public User registerNewUser(UserDTO userDTO){
        User user = new User();
        Role userRole = roleService.findRole("USER");
        PasswordEncoder bcrypt = new BCryptPasswordEncoder();
        user.setUsername(userDTO.getUsername());
        user.setPassword(bcrypt.encode(userDTO.getPassword()));
        user.setEmail(userDTO.getEmail());
        user.addRole(userRole);
        em.persist(user);
        return user;

    }

}
