package com.example.dopamine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DopamineApplicationTests {

    @Test
    void contextLoads() {
    }

}
